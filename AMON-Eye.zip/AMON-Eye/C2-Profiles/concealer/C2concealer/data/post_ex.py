'''

#################################################
Data set containing post_ex block data, including
spawn-to processes. 
#################################################

'''
#CUSTOMIZE THIS LIST#
spawn_processes = ['runonce.exe','svchost.exe','regsvr32.exe','WUAUCLT.exe']

