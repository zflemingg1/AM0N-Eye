##                   put your ip 👇️
./teamserver.AppImage 192.168.1.1  password & ./st.AppImage

